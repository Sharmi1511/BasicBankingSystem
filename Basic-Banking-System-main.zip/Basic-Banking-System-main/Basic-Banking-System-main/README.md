# Basic-Banking-System
Project developed during my Internship at The Sparks Foundation

It is a Basic Banking System for making transactions between users. It can transfer Money between multiple accounts, view all Customer's data and view all the past transactions happened between different accounts.
# Stack used 
FRONT END: HTML, CSS, JavaScript, Bootstrap

BACK END: PHP

DATABASE: MySQL

Flow: Home Page > View all Customers > Select and View one Customer > Transfer Money > Select customer to transfer to > View all Customers .

Check my website here: https://handwebcurrency.000webhostapp.com/
